﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine; // Import Unity

public class HelloWorld : MonoBehaviour {

    // Use this for initialization
    // Starts with Indentation for statement
    // Start is built-in
    void Start () {
        print("Hello World");
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
